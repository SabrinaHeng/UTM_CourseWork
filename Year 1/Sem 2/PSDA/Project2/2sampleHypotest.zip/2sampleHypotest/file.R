install.packages("dplyr")
library(dplyr)
regularly_group <- X2samplehypo %>% filter(`Study regulary or seldom` == "regularly")
seldom_group <- X2samplehypo %>% filter(`Study regulary or seldom` == "Seldom")

#separate group for regular and seldom
head(regularly_group)
head(seldom_group)

#to find n1,n2
studyType.freq <- table(X2samplehypo[,1])
print(studyType.freq)
n1 <- 17
n2 <- 52

regular_hour <- regularly_group$`study hours`
seldom_hour <- seldom_group$`study hours`

#calculate sample standard deviation and mean
sd_regular <- sd(regular_hour)
sd_seldom <- sd(seldom_hour)
mean_regular <- mean(regular_hour)
mean_seldom <- mean(seldom_hour)


#Find F statistical value and F critical value
Fstatistic <- (sd_seldom^2)/(sd_regular^2)
Fcritical <- qf(1-0.05,51,16)
print(Fstatistic)
print(Fcritical)

#to identify it is equal or unequal variance , using F test
if (Fstatistic>Fcritical){
  print("This two sample is Assumed Unequal")
} else if(Fstatistic<-Fcritical){
  print("This two sample is Assumed Unequal")
} else {
  print("This two sample is Assumed Equal")
}

#Perform T test (Independent samples with population unknown and not assumed equal)
t0 = ((mean_seldom - mean_regular - 0)/sqrt( (((sd_seldom)^2)/n1) + (((sd_regular)^2)/n2)))

v = (((sd_regular^2/n1)+(sd_seldom^2/n2))^2)/((((sd_regular^2/n1)^2)/(n1-1))+(((sd_seldom^2/n2)^2)/(n2-1)))


alpha = 0.05
t.alpha = qt(alpha/2,floor(v))

print("T statistical value : ")
print(t0)

print("T critical value : ")
print(t.alpha)

if (t0>t.alpha){
  if(t0<-t.alpha){
    print("Fail to reject H null hypothesis")
  }else{
    print("H null hypothesis rejected")
  }
}else if(t0<-t.alpha){
  if(t0<-t.alpha){
    print("Fail to reject H null hypothesis")
  }else{
    print("H null hypothesis rejected")
  }
} else {
  print("H null hypothesis rejected")
}
library(ggplot2)

# Plot with jitter to reduce overlap
ggplot(data, aes(x = data$`Study Hour`, y = data$CGPA)) +
  geom_jitter(width = 0.2, height = 0) +  # Adding jitter
  geom_smooth(method = "lm", color = "red") +
  labs(title = "Scatterplot of CGPA vs. Study Hours", x = "Study Hours", y = "CGPA")

x <- data$`Study Hour`
y <- data$CGPA
library(plotrix)
plot(x,y, xlab = "Study Hours per day", ylab = "CGPA")

cor(x,y)

r <- 0.0411
n <- 69
t = r/(sqrt((1-(r*r))/(n-2)))
cor.test(x,y)

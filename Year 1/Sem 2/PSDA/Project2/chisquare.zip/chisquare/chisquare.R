library(MASS)
# get the contingency table
tbl <- table(chisquare$`Study habit`,
             chisquare$`Satisfication level for learning mode`)
# create a new table
tbl2 = cbind(tbl[,'1']+tbl[,'2'],tbl[,'3'],tbl[,'4']+tbl[,'5'])
colnames(tbl2) <- c("Not satisfied","Neutral","Satisfied")
print(tbl2)
# perform chi-square test on the data table
chisq.test(tbl2, correct=FALSE)
chi_square_test <- chisq.test(tbl2, correct=FALSE)
expected_Table <- chi_square_test$expected
print(expected_Table)
#critical value
alpha <- 0.05 
x2.alpha <- qchisq(alpha,
df=2,
lower.tail=FALSE)
print(x2.alpha)

satisfactionLearningMode <- DataSET$`Comfortability of study mode`
numCourses <-DataSET$`Number of Courses Taken`

x <-numCourses
y <- satisfactionLearningMode

model <- lm(y~x)
print(model)

plot(x,y, xlim = c(0,20), ylim = c(0,8))
abline(model)
summary(model)

plot(numCourses, satisfactionLearningMode, 
     main = "Scatter Plot without Regression Line", 
     xlab = "Number Of Courses Taken", 
     ylab = "Satisfaction of Learning Mode", 
     pch = 19)

plot(numCourses, satisfactionLearningMode,  xlim = c(0,20), ylim = c(0,8),
     main = "Relationship between Number of Courses Taken and Comfortability of Study Mode", 
     xlab = "Number Of Courses Taken", 
     ylab = "Comfortability of Study Mode", 
     pch = 19)
abline(model, col = "blue")

intercept <- coef(model)[1]
slope <- coef(model)[2]
cat("Intercept (b0):", intercept , "\n")
cat("Slope (b1):", slope, "\n")

sse <- sum(model$residuals^2)
sst <- sum((satisfactionLearningMode - mean(satisfactionLearningMode))^2)
ssr <- sst - sse
cat("SSE:", sse, "\n")
cat("SSR:", ssr, "\n")
cat("SST:", sst, "\n")

r_squared <- summary(model)$r.squared
cat("R-squared:", r_squared, "\n")

slope_std_error <- summary(model)$coefficients[2, "Std. Error"]
cat("Standard Error of Slope (sb1):", slope_std_error, "\n")

t_value <- summary(model)$coefficients[2, "t value"]
p_value <- summary(model)$coefficients[2, "Pr(>|t|)"]
cat("t-value:", t_value, "\n")
cat("p-value:", p_value, "\n")


alpha <- 0.05
df <- nrow(DataSET) - 2
print (df)
if (is.numeric(df) && df > 0) {
  critical_value <- qt((1 - alpha) / 2, df)
  cat("Critical Value:", critical_value, "\n")
  
  if (abs(t_value) > critical_value) {
    cat("Reject the null hypothesis: There is a significant linear relationship.\n")
  } else {
    cat("Fail to reject the null hypothesis: There is no significant linear relationship.\n")
  }
} else {
  cat("Error: Degrees of freedom (df) is not valid.\n")
}